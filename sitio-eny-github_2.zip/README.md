# Centro de Gestión Territorial · Eny · La Libertad Costa

Aplicación web para la gestión de casos y cobertura territorial de la campaña,
con vista de celular y de escritorio.

## 🌐 Cómo publicarla en GitHub Pages (paso a paso)

1. Crea una cuenta gratis en **github.com** (si no tienes).
2. Arriba a la derecha toca **+** → **New repository**.
   - Nombre: `campana-eny` (o el que prefieras)
   - Visibilidad: **Public** (necesario para Pages gratis)
   - Toca **Create repository**.
3. En el repositorio nuevo: **Add file → Upload files**.
   - Arrastra el archivo **index.html** de esta carpeta.
   - Toca **Commit changes**.
4. Ve a **Settings → Pages** (menú izquierdo).
   - En *Source* elige **Deploy from a branch**.
   - Branch: **main** · Carpeta: **/ (root)** → **Save**.
5. Espera 1–2 minutos. Tu app quedará en:
   `https://TU-USUARIO.github.io/campana-eny/`

Comparte ese enlace con el equipo. Se abre en cualquier celular o computadora,
y se puede "instalar" desde el navegador (menú → *Agregar a pantalla de inicio*).

## 💾 Importante sobre los datos

En GitHub Pages los datos se guardan **en el dispositivo de cada persona**
(indicador: "GUARDADO EN ESTE DISPOSITIVO"). Sobreviven al cerrar el navegador,
pero **no se comparten automáticamente** entre miembros del equipo.

Para base de datos compartida en equipo se puede conectar Supabase o Firebase
(gratis) en una siguiente fase.

## 🔄 Actualizar la app

Cuando haya una versión nueva del archivo: repite el paso 3 (subir `index.html`
encima del anterior) y en 1–2 minutos el enlace mostrará la versión nueva.
